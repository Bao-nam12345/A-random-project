# Boblox: publish community games on Netlify with Supabase

## What this fixes
The Add Game feature now writes each submitted game to a shared `community_games` table in Supabase. Other visitors load the published games from that same table, so they can play them on different devices. Supabase Realtime refreshes the gallery when a game is added, edited, or removed. If Supabase is not configured, the page clearly falls back to offline mode; offline games are not shared.

## 1. Configure Supabase Auth
In Supabase Dashboard, open **Authentication → Sign In / Providers** (wording may vary) and enable **Anonymous Sign-Ins**. This lets visitors publish under a unique anonymous user ID without needing an account. For a public site, add rate limits/moderation before wider use.

## 2. Create the shared games table
Open **SQL Editor → New query** and run:

```sql
create table if not exists public.community_games (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 40),
  emoji text not null default '🎲',
  genre text not null,
  description text not null default '',
  code text not null check (char_length(code) between 1 and 60000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists community_games_created_at_idx
  on public.community_games (created_at desc);

alter table public.community_games enable row level security;

grant select on public.community_games to anon, authenticated;
grant insert, update, delete on public.community_games to authenticated;

drop policy if exists "Anyone can view published games" on public.community_games;
create policy "Anyone can view published games"
  on public.community_games for select
  to anon, authenticated using (true);

drop policy if exists "Creators can publish their own games" on public.community_games;
create policy "Creators can publish their own games"
  on public.community_games for insert
  to authenticated with check (auth.uid() = user_id);

drop policy if exists "Creators can edit their own games" on public.community_games;
create policy "Creators can edit their own games"
  on public.community_games for update
  to authenticated using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

drop policy if exists "Creators can delete their own games" on public.community_games;
create policy "Creators can delete their own games"
  on public.community_games for delete
  to authenticated using (auth.uid() = user_id);
```

These policies make published games readable by everyone, while only the creator can edit or delete their own row. Do not disable RLS. This is a basic public UGC setup: review and moderate uploaded game code before using it on a large public site. Game code runs inside a sandboxed iframe, but still treat public submissions as untrusted.

## 3. Add public client config
In Supabase Dashboard, open **Project Settings → API Keys** and copy the **Project URL** and **publishable key** (usually starts `sb_publishable_`). Edit `js/supabase-config.js` in this project:

```js
window.BOBLOX_SUPABASE = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  publishableKey: 'sb_publishable_REPLACE_ME'
};
```

These are browser-visible values; that is expected for a publishable key. Never put a `service_role` or secret key in the website.

## 4. Enable Realtime for gallery refreshes
In **Realtime → Settings**, ensure **Enable Realtime service** is ON. The app uses Supabase Postgres Changes on `public.community_games` to refresh the gallery. In **Database → Replication** (or Publications), make sure `community_games` is included in the `supabase_realtime` publication if your project requires it. Alternatively, users can reload the page to fetch the latest games; publishing still stores them in the shared table.

This is shared game publishing, not real-time multiplayer inside each game. Multiplayer movement/rooms require separate game networking code and private-channel authorization.

## 5. Deploy to Netlify
1. Save the edited `js/supabase-config.js`.
2. Upload the extracted `playhub-3d` folder (the folder containing `index.html`, `css/`, and `js/`) as a manual deploy, or use it as the publish directory for a connected repository.
3. Open the live site in two separate browsers/devices. Publish a test game in one; it should appear in the other after the Realtime subscription updates.

## Notes
- Offline fallback mode intentionally does not claim that local games are shared.
- Visitors use anonymous Supabase auth. Anonymous accounts can be abused on public sites; add moderation, rate limiting, and a way to report games before production launch.
- A published game is a single HTML document. It runs in a sandboxed iframe and does not get access to the parent page's JavaScript.
