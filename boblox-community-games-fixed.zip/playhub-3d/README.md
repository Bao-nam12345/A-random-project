# Boblox

A responsive browser-based 3D mini-game hub, renamed from PlayHub 3D. Includes seven original mini-games plus Duel Arena and Meteor Drift, touch controls, adjustable camera sensitivity, and Shift Lock shoulder-camera mode.

## Run locally
Open `index.html` in a modern browser with internet access (Three.js is loaded from cdnjs). For best results use a local static server.

## Deploy to Netlify
Deploy the folder containing `index.html`, `css/`, and `js/` as a static site. No build command is required.

## Controls
- WASD / arrow keys: move (game-dependent)
- Space: action (game-dependent)
- Drag mouse or touch: rotate camera
- Mouse wheel / pinch: zoom
- Shift or the **Shift Lock** button: toggle shoulder camera and crosshair
- Esc: exit game

Shift Lock is a client-side camera feature. Online multiplayer still requires room membership, authorization, and Realtime integration; Supabase credentials are intentionally not embedded in this static package.
