/* ---------- engine ---------- */
let raf=0,rend=null,upd=null,scn=null,cam=null,last=0,lockWanted=false;
const hud=t=>{$('hud').textContent=t};
function size(){if(!rend)return;const w=innerWidth,h=innerHeight;rend.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix()}
function loop(t){raf=requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1e3);last=t;ET=t/1e3;DT=dt;upd(dt);rend.render(scn,cam)}
function launch(g){
  if(!window.THREE){note('3D engine failed to load');return}
  const cv=document.createElement('canvas');
  try{rend=new T.WebGLRenderer({canvas:cv,antialias:true})}catch(e){note('3D is not supported on this device');return}
  rend.setPixelRatio(Math.min(devicePixelRatio||1,2));
  scn=new T.Scene();cam=new T.PerspectiveCamera(65,1,.1,600);light(scn);
  Object.keys(key).forEach(k=>key[k]=0);
  window.currentGame=g;stg.classList.toggle('duel-mode',g.id==='duel');cc.yaw=0;cc.pitch=g.pitch||.45;cc.dist=g.dist||11;cc.snap=1;ptr.clear();cc.drag=0;upd=g.run(scn,cam,hud);
  $('stage').prepend(cv);$('stage').hidden=false;document.body.style.overflow='hidden';
  size();last=performance.now();raf=requestAnimationFrame(loop);syncShiftLockUI();
}
function quit(){
  cancelAnimationFrame(raf);if(rend){const c=rend.domElement;rend.dispose();rend.forceContextLoss();c.remove();rend=null}
  if(document.pointerLockElement)document.exitPointerLock();lockWanted=false;cc.shiftLock=false;syncShiftLockUI();$('stage').classList.remove('shift-locked');$('stage').hidden=true;document.body.style.overflow='';
}
$('exit').onclick=quit;
addEventListener('resize',size);
const KM={ArrowLeft:'l',KeyA:'l',ArrowRight:'r',KeyD:'r',ArrowUp:'u',KeyW:'u',ArrowDown:'d',KeyS:'d',Space:'a',KeyF:'p2a',Enter:'p2a'};
const P2KM={ArrowLeft:'p2l',ArrowRight:'p2r',ArrowUp:'p2u',ArrowDown:'p2d',KeyA:'p2l',KeyD:'p2r',KeyW:'p2u',KeyS:'p2d'};
function syncShiftLockUI(){const b=$('shiftlock');if(!b)return;b.setAttribute('aria-pressed',String(!!cc.shiftLock));b.textContent=cc.shiftLock?'◎ Shift Lock: ON':'◎ Shift Lock';$('stage').classList.toggle('shift-locked',!!cc.shiftLock)}
function toggleShiftLock(){
  if($('stage').hidden)return;
  cc.shiftLock=!cc.shiftLock;lockWanted=cc.shiftLock;syncShiftLockUI();
  // Pointer Lock is supported on desktop browsers and keeps the mouse captured without holding a button.
  if(cc.shiftLock&&matchMedia('(hover:hover) and (pointer:fine)').matches){
    const c=rend&&rend.domElement;
    if(c&&c.requestPointerLock){try{const p=c.requestPointerLock();if(p&&p.catch)p.catch(()=>note('Shift Lock camera enabled; click the game then press Shift to capture the mouse.'))}catch(e){note('Shift Lock camera enabled; browser did not allow mouse capture.')}}
  }else if(document.pointerLockElement&&document.exitPointerLock){document.exitPointerLock()}
}
$('shiftlock').addEventListener('click',toggleShiftLock);
document.addEventListener('pointerlockchange',()=>{if(document.pointerLockElement===rend?.domElement){lockWanted=true}else if(lockWanted&&cc.shiftLock){/* browser may release capture; keep camera mode on */}});
addEventListener('keydown',e=>{
  if($('stage').hidden)return;
  if(e.code==='ShiftLeft'||e.code==='ShiftRight'){if(!e.repeat){toggleShiftLock()}e.preventDefault();return}
  const duel=window.currentGame&&window.currentGame.id==='duel';
  const dk=duel?({ArrowLeft:'p2l',ArrowRight:'p2r',ArrowUp:'p2u',ArrowDown:'p2d',Enter:'p2a',KeyF:'p2a',KeyA:'l',KeyD:'r',KeyW:'u',KeyS:'d',Space:'a'}):KM;
  const k=dk[e.code];if(k){key[k]=1;e.preventDefault()}if(e.code==='Escape'){if(cc.shiftLock){cc.shiftLock=false;lockWanted=false;syncShiftLockUI();if(document.pointerLockElement)document.exitPointerLock()}else quit()}
});
addEventListener('keyup',e=>{
  const duel=window.currentGame&&window.currentGame.id==='duel';
  const dk=duel?({ArrowLeft:'p2l',ArrowRight:'p2r',ArrowUp:'p2u',ArrowDown:'p2d',Enter:'p2a',KeyF:'p2a',KeyA:'l',KeyD:'r',KeyW:'u',KeyS:'d',Space:'a'}):KM;
  const k=dk[e.code];if(k)key[k]=0;
});
addEventListener('blur',()=>Object.keys(key).forEach(k=>key[k]=0));
$('sens').addEventListener('input',e=>{cc.sensitivity=Number(e.target.value)/100;$('sensval').textContent=e.target.value+'%'});
/* camera: drag to rotate, wheel / pinch to zoom */
const ptr=new Map(),stg=$('stage');
stg.addEventListener('contextmenu',e=>e.preventDefault());
stg.addEventListener('pointerdown',e=>{if(e.target.closest('#pad,#exit'))return;ptr.set(e.pointerId,[e.clientX,e.clientY]);cc.drag=1});
stg.addEventListener('pointermove',e=>{if(cc.shiftLock&&document.pointerLockElement===rend?.domElement){cc.yaw-=e.movementX*.0035*cc.sensitivity;cc.pitch=clamp(cc.pitch+e.movementY*.003*cc.sensitivity,.08,1.4);return}const p=ptr.get(e.pointerId);if(!p)return;
  if(ptr.size===2){const o=[...ptr].find(([id])=>id!==e.pointerId)[1],d0=Math.hypot(p[0]-o[0],p[1]-o[1]),d1=Math.hypot(e.clientX-o[0],e.clientY-o[1]);if(d1>5)cc.dist=clamp(cc.dist*d0/d1,5,45)}
  else{cc.yaw-=(e.clientX-p[0])*.006*cc.sensitivity;cc.pitch=clamp(cc.pitch+(e.clientY-p[1])*.005*cc.sensitivity,.08,1.4)}
  p[0]=e.clientX;p[1]=e.clientY});
['pointerup','pointercancel'].forEach(ev=>stg.addEventListener(ev,e=>{ptr.delete(e.pointerId);if(!ptr.size)cc.drag=0}));
stg.addEventListener('wheel',e=>{cc.dist=clamp(cc.dist*(1+e.deltaY*.001),5,45);e.preventDefault()},{passive:false});
document.querySelectorAll('#pad button').forEach(b=>{const k=b.dataset.k;
  b.onpointerdown=e=>{e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}key[k]=1};
  ['pointerup','pointerleave','pointercancel'].forEach(ev=>b.addEventListener(ev,()=>key[k]=0))});

/* ---------- platform + community publishing ---------- */
let db=null,user=null,uid=null,owner=false,docs={},names={},filter='All',editing=null;
function note(m){const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(note.t);note.t=setTimeout(()=>t.style.display='none',4200)}
function all(){return [...PH.games.map(g=>({...g,uid:null,by:'Boblox'})),...Object.values(docs).flat().map(g=>({...g,by:g.uid===uid?'You':(g.by||'A player')}))]}
function card(g){
 const c=el('div','card'),t=el('div','thumb',g.emoji||'🎲'),b=el('div','body');
 const h=[...g.title].reduce((a,ch)=>a+ch.charCodeAt(0),0)*37%360;
 t.style.background=`linear-gradient(135deg,hsl(${h} 70% 55%),hsl(${(h+55)%360} 70% 38%))`;t.append(el('span','badge',g.uid?'COMMUNITY':'BUILT-IN'));
 b.append(el('b',0,g.title),el('div','mut',g.genre+' · by '+g.by),el('div','desc',g.desc||''));
 const r=el('div','row'),play=el('button','btn pri','▶ Play');play.onclick=()=>g.run?launch(g):playCustom(g);r.append(play);
 if(db&&g.uid===uid){const edit=el('button','btn','Edit');edit.onclick=()=>openEditor(g);r.append(edit);r.append(delBtn(g))}
 b.append(r);c.append(t,b);return c;
}
function delBtn(g){const b=el('button','btn dng','Delete');b.onclick=async()=>{if(b.textContent==='Delete'){b.textContent='Sure?';setTimeout(()=>b.textContent='Delete',2500);return}try{const {error}=await db.from('community_games').delete().eq('id',g.id).eq('user_id',uid);if(error)throw error;note('Game removed from community');await loadCommunity()}catch(e){note('Could not delete: '+(e.message||'check Supabase policies'))}};return b}
function render(){
 $('chips').replaceChildren(...['All',...GENRES].map(n=>{const x=el('button','chip'+(n===filter?' on':''),n);x.onclick=()=>{filter=n;render()};return x}));
 const list=all().filter(g=>filter==='All'||g.genre===filter);$('grid').replaceChildren(...list.map(card));if(!list.length)$('grid').append(el('p','mut','No games in this genre yet.'));
 $('count').textContent=list.length+(list.length===1?' game':' games')+' · community games are shared across devices';
}
function playCustom(g){$('pt').textContent=(g.emoji||'🎮')+' '+g.title;$('fr').srcdoc=g.code||'';$('play').showModal()}
$('pc').onclick=()=>$('play').close();$('play').addEventListener('close',()=>{$('fr').srcdoc='' });
GENRES.forEach(n=>{const o=el('option',0,n);o.value=n;$('ge').append(o)});
function openEditor(g){editing=g||null;$('et').textContent=g?'Edit community game':'Publish a game for everyone';$('ti').value=g?g.title:'';$('em').value=g?g.emoji:'🎲';$('ge').value=g?g.genre:'Action';$('de').value=g?g.desc:'';$('co').value=g?g.code:STARTER;$('ed').showModal()}
$('add').onclick=()=>{if(!db||!uid){note('Community publishing needs Supabase setup. See SUPABASE_SETUP.md');return}openEditor(null)};$('ec').onclick=()=>$('ed').close();
$('es').onclick=async()=>{
 const g={title:$('ti').value.trim(),emoji:$('em').value.trim()||'🎲',genre:$('ge').value,description:$('de').value.trim(),code:$('co').value};
 if(!g.title||!g.code.trim()){note('Add a title and game code');return}if(g.code.length>60000){note('Game code is too large (60,000 characters max)');return}
 try{let q;if(editing){q=await db.from('community_games').update(g).eq('id',editing.id).eq('user_id',uid)}else{q=await db.from('community_games').insert({...g,user_id:uid})}if(q.error)throw q.error;$('ed').close();note('Published! Other visitors can now see this game.');await loadCommunity()}catch(e){note('Publish failed: '+(e.message||'Check setup in SUPABASE_SETUP.md'))}
};
async function loadCommunity(){if(!db)return;const {data,error}=await db.from('community_games').select('id,user_id,title,emoji,genre,description,code,created_at').order('created_at',{ascending:false}).limit(200);if(error)throw error;docs={};for(const row of data||[]){const g={...row,desc:row.description,uid:row.user_id,by:row.user_id===uid?'You':'Community creator'};(docs[g.uid] ||= []).push(g)}render()}
async function bootSupabase(){
 const cfg=window.BOBLOX_SUPABASE;if(!cfg||!cfg.url||!cfg.publishableKey||cfg.url.includes('YOUR_PROJECT'))return false;
 if(!window.supabase?.createClient)return false;
 db=window.supabase.createClient(cfg.url,cfg.publishableKey);let {data:{session}}=await db.auth.getSession();if(!session){const r=await db.auth.signInAnonymously();if(r.error)throw r.error;session=r.data.session}uid=session.user.id;user=session.user;
 $('who').textContent='Community publishing enabled · guest creator';$('add').hidden=false;
 await loadCommunity();db.channel('community-games-live').on('postgres_changes',{event:'*',schema:'public',table:'community_games'},()=>loadCommunity().catch(()=>{})).subscribe();return true;
}
render();
(async()=>{try{if(await bootSupabase())return;localMode()}catch(e){console.error(e);note('Community service unavailable: '+(e.message||'check Supabase setup'));localMode()}})();

/* hero: floating 3D shapes */
(function(){try{
  const c=$('hero'),r=new T.WebGLRenderer({canvas:c,alpha:true,antialias:true}),s=new T.Scene(),cm=new T.PerspectiveCamera(50,1,.1,100);
  cm.position.z=14;light(s);
  const gs=[new T.IcosahedronGeometry(1),new T.OctahedronGeometry(1.1),new T.TorusKnotGeometry(.7,.25,60,8),new T.BoxGeometry(1.4,1.4,1.4)];
  const ms=[...Array(16)].map((_,i)=>{const m=new T.Mesh(gs[i%4],mat(new T.Color().setHSL(i/16,.7,.6).getHex()));
    m.position.set((Math.random()-.5)*26,(Math.random()-.5)*8,(Math.random()-.5)*8-2);m.userData.s=.3+Math.random();s.add(m);return m});
  const f=t=>{requestAnimationFrame(f);if(!$('stage').hidden)return;
    const w=c.clientWidth,h=c.clientHeight;if(c.width!==w||c.height!==h){r.setSize(w,h,false);cm.aspect=w/h;cm.updateProjectionMatrix()}
    ms.forEach((m,i)=>{m.rotation.x=t*.0004*m.userData.s;m.rotation.y=t*.0006*m.userData.s;m.position.y+=Math.sin(t*.001+i)*.004});r.render(s,cm)};
  f(0)}catch(e){}})();

/* Offline fallback: local drafts only; these are NOT shared with other players. */
function localMode(){
 uid='local';try{const saved=JSON.parse(localStorage.getItem('boblox_local_games')||'[]');docs={local:saved.map(g=>({...g,uid:'local',by:'You'}))}}catch(e){docs={local:[]}}
 $('who').textContent='Offline mode · games are only saved on this device';$('add').hidden=false;
 // Keep the editor honest: local saves are not presented as community publishing.
 $('add').onclick=()=>note('To publish games for everyone, configure Supabase using SUPABASE_SETUP.md.');render();
}
