// Public browser configuration only. Replace these two placeholders with your Supabase project values.
window.BOBLOX_SUPABASE = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  publishableKey: 'sb_publishable_REPLACE_ME'
};
