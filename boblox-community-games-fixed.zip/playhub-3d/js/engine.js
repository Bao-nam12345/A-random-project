const T=window.THREE;
const GENRES=["Arcade","Platformer","Racing","Action","Adventure","Puzzle","Party","Strategy","Other"];
const STARTER=`<style>body{margin:0;overflow:hidden}</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"><\/script>
<script>
const r=new THREE.WebGLRenderer({antialias:true});r.setSize(innerWidth,innerHeight);document.body.append(r.domElement);
const s=new THREE.Scene(),c=new THREE.PerspectiveCamera(60,innerWidth/innerHeight,.1,100);c.position.z=4;
s.add(new THREE.HemisphereLight(0xffffff,0x444444,1));
const m=new THREE.Mesh(new THREE.BoxGeometry(),new THREE.MeshLambertMaterial({color:0x5b5bf0}));s.add(m);
(function f(){requestAnimationFrame(f);m.rotation.y+=.02;r.render(s,c)})();
<\/script>`;

const $=id=>document.getElementById(id);
const el=(t,c,x)=>{const e=document.createElement(t);if(c)e.className=c;if(x!=null)e.textContent=x;return e};
const mat=c=>new T.MeshLambertMaterial({color:c});
const box=(w,h,d,c)=>new T.Mesh(new T.BoxGeometry(w,h,d),mat(c));
const ball=(r,c)=>new T.Mesh(new T.SphereGeometry(r,16,12),mat(c));
const light=s=>{s.add(new T.HemisphereLight(0xffffff,0x556677,.95));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(5,12,6);s.add(d)};
const key={l:0,r:0,u:0,d:0,a:0,p2l:0,p2r:0,p2u:0,p2d:0,p2a:0};
const PH={games:[]};
let ET=0,DT=.016;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const cc={yaw:0,pitch:.45,dist:11,drag:0,snap:1,sensitivity:1,shiftLock:false};
/* Roblox-style camera: drag = rotate, wheel/pinch = zoom. base = extra yaw (vehicles), rec = re-centre when not dragging */
function orbit(cam,x,y,z,base,rec){
  if(rec&&!cc.drag)cc.yaw*=1-Math.min(1,DT*1.5);
  const yw=(base||0)+cc.yaw,cp=Math.cos(cc.pitch),shoulder=cc.shiftLock?0.85:0,p=new T.Vector3(x+Math.sin(yw)*cp*cc.dist+Math.cos(yw)*shoulder,y+Math.sin(cc.pitch)*cc.dist,z+Math.cos(yw)*cp*cc.dist-Math.sin(yw)*shoulder);
  if(cc.snap){cam.position.copy(p);cc.snap=0}else cam.position.lerp(p,Math.min(1,DT*12));
  cam.lookAt(x,y,z);
}
/* movement direction relative to the camera, like Roblox */
function dirv(){const f=key.u-key.d,r=key.r-key.l,s=Math.sin(cc.yaw),c=Math.cos(cc.yaw),a=-s*f+c*r,b=-c*f-s*r,l=Math.hypot(a,b);return l>1?[a/l,b/l]:[a,b]}
const hi=(id,v)=>{try{const k='ph_'+id,b=Math.max(+localStorage.getItem(k)||0,v);localStorage.setItem(k,b);return b}catch(e){return v}};
/* blocky Roblox-style avatar. o:{skin,shirt,pants,hat,s}. avatar.userData.anim(speed) swings the limbs */
function acc(g,type){
  const add=(m,x,y,z)=>{m.position.set(x,y,z);g.add(m)};
  if(type==='ears'){[-.25,.25].forEach(x=>{add(box(.25,1,.25,0xffffff),x,3.7,0);add(box(.1,.8,.1,0xf8bbd0),x,3.7,.1)})}
  if(type==='visor')add(new T.Mesh(new T.BoxGeometry(.95,.28,.12),new T.MeshBasicMaterial({color:0x00e5ff})),0,2.8,.5);
  if(type==='helmet')add(new T.Mesh(new T.BoxGeometry(1.15,1.15,1.15),new T.MeshLambertMaterial({color:0x90caf9,transparent:true,opacity:.35})),0,2.75,0);
  if(type==='hard'){add(box(1,.3,1,0xffeb3b),0,3.3,0);add(box(1.1,.08,.5,0xffeb3b),0,3.2,.5)}
  if(type==='pirate'){add(box(1,.3,1,0xc62828),0,3.3,0);add(box(1.4,.12,1.4,0x212121),0,3.5,0);add(box(.7,.35,.7,0x212121),0,3.7,0)}
  if(type==='cap'){add(box(1,.25,1,0xd32f2f),0,3.3,0);add(box(.9,.07,.5,0xd32f2f),0,3.25,.6)}
}
function avatar(o){
  o=o||{};const g=new T.Group(),sk=o.skin==null?0xffcc66:o.skin,sh=o.shirt==null?0x2196f3:o.shirt,pn=o.pants==null?0x37474f:o.pants;
  const cv=document.createElement('canvas');cv.width=cv.height=64;const c=cv.getContext('2d');
  c.fillStyle='#'+sk.toString(16).padStart(6,'0');c.fillRect(0,0,64,64);c.fillStyle='#222';
  c.fillRect(16,20,9,12);c.fillRect(39,20,9,12);c.fillRect(20,44,24,4);c.fillRect(16,40,4,5);c.fillRect(44,40,4,5);
  const hm=mat(sk),head=new T.Mesh(new T.BoxGeometry(.9,.9,.9),[hm,hm,hm,hm,new T.MeshLambertMaterial({map:new T.CanvasTexture(cv)}),hm]);
  head.position.y=2.75;const to=box(1.1,1.2,.55,sh);to.position.y=1.7;
  const lb=(w,h,col,x,y)=>{const p=new T.Group(),m=box(w,h,w,col);m.position.y=-h/2;p.add(m);p.position.set(x,y,0);return p};
  const la=lb(.45,1.15,sh,-.78,2.25),ra=lb(.45,1.15,sh,.78,2.25),ll=lb(.5,1.1,pn,-.28,1.1),rl=lb(.5,1.1,pn,.28,1.1);
  g.add(head,to,la,ra,ll,rl);acc(g,o.hat);g.scale.setScalar(o.s||.5);
  g.userData.anim=s=>{const a=Math.sin(ET*11)*(s||0)*.9;la.rotation.x=a;ra.rotation.x=-a;ll.rotation.x=-a;rl.rotation.x=a};
  return g;
}

/* ---------- 3D games ---------- */
