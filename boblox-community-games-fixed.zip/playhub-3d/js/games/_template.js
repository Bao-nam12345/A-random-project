// Copy this file, rename it, edit it, then add
//   <script src="js/games/yourgame.js"></script>
// to index.html (before platform.js). Your game shows up in the lobby automatically.
function myGame(sc,cam,hud){
  sc.background=new T.Color(0x87ceeb);
  const floor=box(30,.4,30,0x66bb6a);floor.position.y=-.2;sc.add(floor);
  const me=avatar({shirt:0xff5722,pants:0x37474f,hat:'cap',s:.5});sc.add(me);   // hats: ears visor helmet hard pirate cap
  let x=0,z=0;
  return dt=>{                                              // called every frame
    const[mx,mz]=dirv();x+=mx*8*dt;z+=mz*8*dt;              // arrows / WASD / touch pad, relative to the camera
    me.position.set(x,0,z);if(mx||mz)me.rotation.y=Math.atan2(mx,mz);me.userData.anim(Math.hypot(mx,mz));
    orbit(cam,x,1.5,z);                                     // Roblox-style camera (drag to rotate, wheel to zoom)
    hud('My game - '+(key.a?'Space pressed':'walk around'));
  };
}
PH.games.push({id:'mygame',title:'My Game',genre:'Other',emoji:'⭐',hero:'My hero',desc:'Describe your game here.',run:myGame});
