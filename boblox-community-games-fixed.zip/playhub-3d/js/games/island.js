function island(sc,cam,hud){
  sc.background=new T.Color(0xffb27a);sc.fog=new T.Fog(0xffb27a,40,160);
  const sea=new T.Mesh(new T.PlaneGeometry(800,800),mat(0x1e90c8));sea.rotation.x=-Math.PI/2;sea.position.y=-1.2;sc.add(sea);
  const sand=new T.Mesh(new T.CylinderGeometry(30,34,2,40),mat(0xe8d08a));sand.position.y=-1;sc.add(sand);
  const gr=new T.Mesh(new T.CylinderGeometry(24,26,.3,40),mat(0x4caf50));gr.position.y=.05;sc.add(gr);
  const rnd=r=>{const a=Math.random()*6.283,d=Math.sqrt(Math.random())*r;return[Math.cos(a)*d,Math.sin(a)*d]};
  const trees=[];
  for(let i=0;i<24;i++){const[x,z]=rnd(22),g=new T.Group(),t=new T.Mesh(new T.CylinderGeometry(.3,.4,2),mat(0x7b4a1e)),l=new T.Mesh(new T.ConeGeometry(1.6,4,8),mat(0x1b7a3a));t.position.y=1;l.position.y=4;g.add(t,l);g.position.set(x,0,z);sc.add(g);trees.push([x,z])}
  const me=avatar({shirt:0xb71c1c,pants:0x4e342e,hat:'pirate',s:.5});sc.add(me);const clk=[];for(let i=0;i<3;i++){const[cx,cz]=rnd(20),m=new T.Mesh(new T.TorusGeometry(.5,.18,8,16),mat(0x40c4ff));m.position.set(cx,1.4,cz);sc.add(m);clk.push(m)}
  const gems=[];let x,z,y,vy,t,got,done;
  const reset=()=>{gems.forEach(g=>sc.remove(g));gems.length=0;
    for(let i=0;i<12;i++){let p;do p=rnd(22);while(trees.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<2));
      const g=new T.Mesh(new T.OctahedronGeometry(.6),mat(new T.Color().setHSL(i/12,.8,.6).getHex()));g.position.set(p[0],1.2,p[1]);sc.add(g);gems.push(g)}
    x=0;z=0;y=0;vy=0;t=60;got=0;done=0;clk.forEach(m=>m.visible=true)};reset();
  return dt=>{
    if(done){hud(done===1?`All 12 gems! ${t.toFixed(1)}s left - press Space`:`Time's up! ${got}/12 gems - press Space`);if(key.a)reset();return}
    t-=dt;if(t<=0)done=2;
    const[mx,mz]=dirv();x+=mx*9*dt;z+=mz*9*dt;if(key.a&&y===0)vy=9;vy-=26*dt;y=Math.max(0,y+vy*dt);if(y===0&&vy<0)vy=0;
    const r=Math.hypot(x,z);if(r>26){x*=26/r;z*=26/r}
    trees.forEach(q=>{const dx=x-q[0],dz=z-q[1],d=Math.hypot(dx,dz);if(d<1.2&&d>0){x=q[0]+dx/d*1.2;z=q[1]+dz/d*1.2}});
    me.position.set(x,y,z);if(mx||mz)me.rotation.y=Math.atan2(mx,mz);me.userData.anim(y>0?.3:Math.hypot(mx,mz));clk.forEach(m=>{if(m.visible){m.rotation.y+=dt*3;if(Math.hypot(m.position.x-x,m.position.z-z)<1.4){m.visible=false;t+=8;note('+8 seconds!')}}});
    for(let i=gems.length-1;i>=0;i--){const g=gems[i];g.rotation.y+=dt*2;g.position.y=1.2+Math.sin(performance.now()/300+i)*.25;
      if(Math.hypot(g.position.x-x,g.position.z-z)<1.3){sc.remove(g);gems.splice(i,1);got++;if(got===12)done=1}}
    orbit(cam,x,1.8,z);
    hud(`Gems ${got}/12   ·   ${Math.max(0,t).toFixed(0)}s`)
  }
}
PH.games.push({id:'island',title:'Gem Island: 12-Gem Treasure Hunt',genre:'Adventure',emoji:'🏝️',hero:'Pip the pirate',desc:'Find 12 gems in 60 seconds. Blue rings add 8 seconds. Space jumps.',run:island,dist:13});
