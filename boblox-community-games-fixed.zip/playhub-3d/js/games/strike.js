function strike(sc,cam,hud){
  sc.background=new T.Color(0x03030c);
  const N=400,pos=new Float32Array(N*3);
  for(let i=0;i<N;i++){pos[i*3]=(Math.random()-.5)*160;pos[i*3+1]=(Math.random()-.5)*90;pos[i*3+2]=-Math.random()*200}
  const sg=new T.BufferGeometry();sg.setAttribute('position',new T.BufferAttribute(pos,3));
  sc.add(new T.Points(sg,new T.PointsMaterial({color:0xffffff,size:.5})));
  const G=new T.Group(),sh=new T.Mesh(new T.ConeGeometry(.8,2.6,4),mat(0x4dd0ff));sh.rotation.x=-Math.PI/2;
  const wg=box(3,.12,1,0x2196f3);wg.position.z=.4;const nv=avatar({shirt:0xffffff,pants:0xeeeeee,hat:'helmet',s:.3});nv.position.set(0,.45,.3);nv.rotation.y=Math.PI;G.add(sh,wg,nv);sc.add(G);
  const EG=new T.OctahedronGeometry(1.2),BG=new T.BoxGeometry(.2,.2,1.4),bm=new T.MeshBasicMaterial({color:0xffe066});
  let bl=[],en=[],sx,sy,cd,pts,lv,sp,over,tri,best=0;
  const reset=()=>{[...bl,...en].forEach(o=>sc.remove(o));bl=[];en=[];sx=0;sy=0;cd=0;pts=0;lv=3;sp=0;tri=0;over=false};reset();
  const cl=(v,m)=>Math.max(-m,Math.min(m,v));
  return dt=>{
    const a=sg.attributes.position.array;for(let i=2;i<a.length;i+=3){a[i]+=dt*70;if(a[i]>10)a[i]-=210}sg.attributes.position.needsUpdate=true;
    if(over){hud(`Game over - score ${pts} · best ${best}. Press Space`);if(key.a)reset()}
    else{
      sx=cl(sx+(key.r-key.l)*22*dt,14);sy=cl(sy+(key.u-key.d)*16*dt,8);G.position.set(sx,sy,0);G.rotation.z=-(key.r-key.l)*.5;
      cd-=dt;tri-=dt;if(key.a&&cd<=0){cd=.18;(tri>0?[-1.2,0,1.2]:[0]).forEach(o=>{const b=new T.Mesh(BG,bm);b.position.set(sx+o,sy,-2);sc.add(b);bl.push(b)})}
      sp-=dt;if(sp<=0){sp=Math.max(.35,1-pts/500);const e=new T.Mesh(EG,mat(0xff4466));e.position.set((Math.random()-.5)*28,(Math.random()-.5)*14,-130);e.userData.v=28+Math.random()*16+pts/20;sc.add(e);en.push(e)}
      for(let i=bl.length-1;i>=0;i--){const b=bl[i];b.position.z-=80*dt;if(b.position.z<-140){sc.remove(b);bl.splice(i,1)}}
      for(let i=en.length-1;i>=0;i--){const e=en[i];e.position.z+=e.userData.v*dt;e.rotation.x+=dt*2;e.rotation.y+=dt*3;let dead=0;
        for(let j=bl.length-1;j>=0;j--)if(bl[j].position.distanceTo(e.position)<2.2){sc.remove(bl[j]);bl.splice(j,1);pts+=10;if(pts%100===0)tri=8;dead=1;break}
        if(!dead&&((e.position.z>-1&&e.position.distanceTo(G.position)<2.2)||e.position.z>8)){lv--;dead=1}
        if(dead){sc.remove(e);en.splice(i,1)}}
      if(lv<=0){over=true;best=hi('strike',pts)}
      hud(`Score ${pts}   ❤ ${lv}${tri>0?'   ⚡ triple shot':''}`)
    }
    orbit(cam,sx*.4,sy*.4,-6,0,1);
  }
}
PH.games.push({id:'strike',title:'Star Strike: Alien Blaster',genre:'Action',emoji:'🛸',hero:'Captain Nova, the astronaut',desc:'Blast alien drones. Every 100 points unlocks triple shot. Arrows fly, Space fires.',run:strike,dist:12,pitch:.2});
