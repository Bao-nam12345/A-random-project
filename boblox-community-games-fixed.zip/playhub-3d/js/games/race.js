function race(sc,cam,hud){
  sc.background=new T.Color(0x9fd8ff);sc.fog=new T.Fog(0x9fd8ff,60,260);
  const R=45,W=7;
  const g=new T.Mesh(new T.PlaneGeometry(700,700),mat(0x3a8f3a));g.rotation.x=-Math.PI/2;g.position.y=-.05;sc.add(g);
  const tr=new T.Mesh(new T.RingGeometry(R-W,R+W,72),mat(0x444a55));tr.rotation.x=-Math.PI/2;sc.add(tr);
  for(let i=0;i<48;i++){const a=i/48*Math.PI*2;[-1,1].forEach(s=>{const m=box(.8,.6,.8,i%2?0xffffff:0xe53935);m.position.set(Math.cos(a)*(R+s*W),.3,Math.sin(a)*(R+s*W));sc.add(m)})}
  const line=box(W*2,.05,1.6,0xffffff);line.position.set(R,.03,0);sc.add(line);
  for(let i=0;i<45;i++){const a=Math.random()*6.283,r=Math.random()<.5?Math.random()*(R-W-6):R+W+6+Math.random()*70;
    const tg=new T.Group(),tk=new T.Mesh(new T.CylinderGeometry(.3,.4,2),mat(0x7b4a1e)),lf=new T.Mesh(new T.ConeGeometry(1.7,4.5,8),mat(0x1b7a3a));tk.position.y=1;lf.position.y=4;tg.add(tk,lf);tg.position.set(Math.cos(a)*r,0,Math.sin(a)*r);sc.add(tg)}
  const car=new T.Group(),bd=box(1.8,.6,3.4,0xff2d55),ad=avatar({shirt:0xff9800,pants:0x37474f,hat:'helmet',s:.32});bd.position.y=.6;ad.position.set(0,.8,-.2);car.add(bd,ad);
  [[-.95,1.1],[.95,1.1],[-.95,-1.1],[.95,-1.1]].forEach(w=>{const m=box(.3,.7,.7,0x111111);m.position.set(w[0],.35,w[1]);car.add(m)});
  sc.add(car);
  const rv=new T.Group(),rb=box(1.8,.6,3.4,0x2979ff),rd=avatar({shirt:0x7c4dff,pants:0x37474f,hat:'helmet',s:.32});rb.position.y=.6;rd.position.set(0,.8,-.2);rv.add(rb,rd);sc.add(rv);
  const pads=[];for(let i=0;i<6;i++){const q=i*Math.PI/3+.35,m=box(6,.06,3,0xffeb3b);m.position.set(Math.cos(q)*R,.04,Math.sin(q)*R);m.rotation.y=-q;sc.add(m);pads.push([m.position.x,m.position.z])}
  let x,z,a,v,total,last,t,fin,rt;
  const reset=()=>{x=R;z=0;a=0;v=0;total=0;last=0;t=0;fin=0;rt=0};reset();
  return dt=>{
    if(fin){hud(`${fin===1?'🏆 You won!':'Rival won.'} ${t.toFixed(1)}s - press Space`);if(key.a)reset()}
    else{
      t+=dt;rt+=dt*(.66+Math.sin(t*.4)*.05);
      const bst=pads.some(q=>Math.hypot(x-q[0],z-q[1])<3.6);
      v+=(key.u?28:key.d?-24:0)*dt+(bst?50*dt:0);v-=v*Math.min(1,.6*dt);
      if(Math.abs(Math.hypot(x,z)-R)>W)v-=v*Math.min(1,2.5*dt);
      v=Math.max(-10,Math.min(bst?56:42,v));
      a+=(key.l-key.r)*1.9*dt*Math.min(1,Math.abs(v)/8)*(v<0?-1:1);
      x+=Math.sin(a)*v*dt;z+=Math.cos(a)*v*dt;
      const th=Math.atan2(z,x);let d=th-last;if(d>Math.PI)d-=2*Math.PI;if(d<-Math.PI)d+=2*Math.PI;total+=d;last=th;
      const lap=Math.max(0,Math.floor(total/(2*Math.PI)));
      if(lap>=3)fin=1;else if(rt>=6*Math.PI)fin=2;
      hud(`${total>rt?'1st':'2nd'}  ·  Lap ${Math.min(lap+1,3)}/3  ·  ${t.toFixed(1)}s  ·  ${Math.abs(v*3.6)|0} km/h`);
    }
    car.position.set(x,0,z);car.rotation.y=a;
    rv.position.set(Math.cos(rt)*(R-2.8),0,Math.sin(rt)*(R-2.8));rv.rotation.y=-rt;
    orbit(cam,x+Math.sin(a)*3,1,z+Math.cos(a)*3,a+Math.PI,1);
  }
}
PH.games.push({id:'race',title:'Turbo Ring Grand Prix: 3-Lap Race',genre:'Racing',emoji:'🏎️',hero:'Rex, the kart driver',desc:'Race a rival for 3 laps. Hit the yellow boost pads! ▲ gas, ▼ brake, ◀ ▶ steer.',run:race,dist:10});
