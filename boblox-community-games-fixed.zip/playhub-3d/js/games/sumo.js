function sumo(sc,cam,hud){
  sc.background=new T.Color(0xb3e5fc);sc.fog=new T.Fog(0xb3e5fc,60,240);
  const sea=new T.Mesh(new T.PlaneGeometry(800,800),mat(0x29b6f6));sea.rotation.x=-Math.PI/2;sea.position.y=-8;sc.add(sea);
  const ar=new T.Mesh(new T.CylinderGeometry(1,1,1.2,48),mat(0xff7043));ar.position.y=-.6;sc.add(ar);
  const E=[{m:avatar({shirt:0x1976d2,pants:0x263238,hat:'cap',s:.55})}];
  [0xe53935,0x43a047,0xfdd835,0x8e24aa].forEach((c,i)=>E.push({m:avatar({shirt:c,pants:0x37474f,hat:i%2?'hard':'cap',s:.55})}));
  E.forEach(e=>sc.add(e.m));const pl=E[0];
  let R,t,kills,over,pa=0,cd,best=0,face=0;
  const reset=()=>{R=14;t=0;kills=0;over=0;cd=0;E.forEach((e,i)=>{const a=i*Math.PI*2/5+.3;Object.assign(e,{x:Math.cos(a)*6,z:Math.sin(a)*6,vx:0,vz:0,y:0,vy:0,on:1,f:0,dash:2+i});e.m.visible=true})};reset();
  return dt=>{
    const press=key.a&&!pa;pa=key.a;
    if(over){hud(over===1?`🏆 You win! ${kills} knock-outs - press Space`:`Knocked out! ${kills} knock-outs · best ${best} - press Space`);if(press)reset()}
    else{
      t+=dt;R=Math.max(6,14-t*.12);cd-=dt;ar.scale.set(R,1,R);
      const[mx,mz]=dirv();
      if(!pl.f){pl.vx+=mx*40*dt;pl.vz+=mz*40*dt;if(mx||mz)face=Math.atan2(mx,mz);if(press&&cd<=0){cd=1.2;pl.vx+=Math.sin(face)*20;pl.vz+=Math.cos(face)*20}}
      E.forEach((e,i)=>{if(!e.on)return;
        if(!e.f){
          if(i){const dx=pl.x-e.x,dz=pl.z-e.z,d=Math.hypot(dx,dz)||1,r=Math.hypot(e.x,e.z)||1;
            e.vx+=dx/d*22*dt;e.vz+=dz/d*22*dt;
            if(r>R-2.5){e.vx-=e.x/r*40*dt;e.vz-=e.z/r*40*dt}
            e.dash-=dt;if(e.dash<=0&&d<5){e.dash=3+Math.random()*2;e.vx+=dx/d*18;e.vz+=dz/d*18}}
          const f=1-Math.min(1,2.2*dt);e.vx*=f;e.vz*=f;e.x+=e.vx*dt;e.z+=e.vz*dt;
          if(Math.hypot(e.x,e.z)>R)e.f=1}
        else{e.vy-=30*dt;e.y+=e.vy*dt;if(e.y<-12){e.on=0;e.m.visible=false;if(i)kills++}}
        e.m.position.set(e.x,e.y,e.z);const sp=Math.hypot(e.vx,e.vz);if(sp>1)e.m.rotation.y=Math.atan2(e.vx,e.vz);e.m.userData.anim(Math.min(1,sp/8))});
      for(let i=0;i<5;i++)for(let j=i+1;j<5;j++){const a=E[i],b=E[j];if(!a.on||!b.on||a.f||b.f)continue;
        const dx=a.x-b.x,dz=a.z-b.z,d=Math.hypot(dx,dz);
        if(d<1.5&&d>0){const nx=dx/d,nz=dz/d,k=(a.vx-b.vx)*nx+(a.vz-b.vz)*nz,o=(1.5-d)/2;
          a.x+=nx*o;a.z+=nz*o;b.x-=nx*o;b.z-=nz*o;
          if(k<0){a.vx-=nx*k*1.6;a.vz-=nz*k*1.6;b.vx+=nx*k*1.6;b.vz+=nz*k*1.6}}}
      if(!pl.on){over=2;best=hi('sumo',kills*10+Math.round(t))}
      else if(E.slice(1).every(e=>!e.on)){over=1;best=hi('sumo',kills*10+Math.round(t)+50)}
      hud(`Knock-outs ${kills} · Dash ${cd>0?cd.toFixed(1)+'s':'ready (Space / A)'} · Arena ${R.toFixed(0)}`)
    }
    orbit(cam,pl.x*.5,0,pl.z*.5);
  }
}
PH.games.push({id:'sumo',title:'Sumo Slam: Last Bot Standing',genre:'Party',emoji:'🤼',hero:'Sam, the sumo champ',desc:'Bump four rivals off the shrinking arena. Space dashes. Last one standing wins!',run:sumo,dist:20,pitch:.7});
