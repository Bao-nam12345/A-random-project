function duel(sc,cam,hud){
  sc.background=new T.Color(0x10152e);
  const floor=box(32,.5,32,0x20294d);floor.position.y=-.3;sc.add(floor);
  for(let i=0;i<4;i++){const wall=box(32,1,1,0x5364a8);wall.position.set(0,.2,i%2?15.5:-15.5);sc.add(wall);const side=box(1,1,30,0x5364a8);side.position.set(i%2?15.5:-15.5,.2,0);sc.add(side)}
  const p1=avatar({shirt:0x00d9ff,pants:0x173c86,hat:'visor',s:.65}),p2=avatar({shirt:0xff4081,pants:0x651c58,hat:'hard',s:.65});sc.add(p1,p2);
  const orb=new T.Mesh(new T.SphereGeometry(.45,16,12),mat(0xffed65));sc.add(orb);
  let a,b,score1,score2,cd,pa,pb;
  const reset=()=>{a={x:-5,z:0,hp:3,face:Math.PI/2,shot:0,flash:0};b={x:5,z:0,hp:3,face:-Math.PI/2,shot:0,flash:0};score1=0;score2=0;cd=1;pa=pb=0};reset();
  const shots=[];
  const fire=(o,team)=>{const m=new T.Mesh(new T.SphereGeometry(.28,10,8),mat(team===1?0x65f6ff:0xff86c4));m.position.set(o.x,1.1,o.z);sc.add(m);shots.push({m,team,vx:Math.sin(o.face)*18,vz:Math.cos(o.face)*18,life:1.3})};
  const clampPos=o=>{o.x=clamp(o.x,-14,14);o.z=clamp(o.z,-14,14)};
  return dt=>{
    const p1fire=key.a&&!pa,p2fire=key.p2a&&!pb;pa=key.a;pb=key.p2a;cd=Math.max(0,cd-dt);
    [[a,p1,key.l,key.r,key.u,key.d,1],[b,p2,key.p2l,key.p2r,key.p2u,key.p2d,2]].forEach(([o,m,l,r,u,d,team])=>{
      const mx=r-l,mz=d-u;if(mx||mz){const n=Math.hypot(mx,mz)||1;o.x+=mx/n*9*dt;o.z+=mz/n*9*dt;o.face=Math.atan2(mx,-mz);m.userData.anim(1)}else m.userData.anim(0);
      clampPos(o);m.position.set(o.x,0,o.z);m.rotation.y=o.face;o.flash=Math.max(0,o.flash-dt);m.visible=o.flash===0||Math.floor(o.flash*16)%2===0;
    });
    if(p1fire)fire(a,1);if(p2fire)fire(b,2);
    for(let i=shots.length-1;i>=0;i--){const q=shots[i];q.m.position.x+=q.vx*dt;q.m.position.z+=q.vz*dt;q.life-=dt;const target=q.team===1?b:a;
      if(Math.hypot(q.m.position.x-target.x,q.m.position.z-target.z)<.9){target.hp--;target.flash=.5;target.x+=(q.team===1?1:-1)*.8;q.life=0;if(target.hp<=0){if(q.team===1)score1++;else score2++;reset();note('Round reset!')}}
      if(q.life<=0||Math.abs(q.m.position.x)>16||Math.abs(q.m.position.z)>16){sc.remove(q.m);shots.splice(i,1)}
    }
    orb.position.set(0,.5+Math.sin(ET*4)*.2,0);orbit(cam,0,1,0,0,1);
    hud(`LOCAL 2 PLAYER DUEL  ·  Blue ${a.hp} HP (${score1})  ·  Pink ${b.hp} HP (${score2})  ·  WASD + Space / Arrows + Enter`);
  }
}
PH.games.push({id:'duel',title:'Duel Arena: Local 2-Player Showdown',genre:'Party',emoji:'⚔️',hero:'Blue vs Pink',desc:'Real local multiplayer: two people fight in the same arena. P1: WASD + Space. P2: arrows + Enter. Mobile: use both touch pads.',run:duel,dist:22,pitch:1.1});
