function stack(sc,cam,hud){
  sc.background=new T.Color(0x1d2a4d);cam.position.set(10,8,10);
  const fl=box(40,.4,40,0x2e3b6b);fl.position.y=-.2;sc.add(fl);
  const bob=avatar({shirt:0xff9800,pants:0x1565c0,hat:'hard',s:.7});bob.position.set(5,0,0);bob.rotation.y=-Math.PI/2.5;sc.add(bob);
  const fa=[];let cheer=0,perf=0,best=0;
  let top,n,ax,dir,m,over,pa=0,blocks=[];
  const col=i=>new T.Color().setHSL((i*.045)%1,.65,.55).getHex();
  const mk=(x,z,w,d,i)=>{const b=box(w,1,d,col(i));b.position.set(x,i+.5,z);sc.add(b);blocks.push(b);return b};
  const spawn=()=>{m=mk(ax?top.x:-9,ax?-9:top.z,top.w,top.d,n);dir=1};
  const reset=()=>{blocks.forEach(b=>sc.remove(b));blocks=[];top={x:0,z:0,w:4,d:4};mk(0,0,4,4,0);n=1;ax=0;over=false;fa.forEach(f=>sc.remove(f.m));fa.length=0;perf=0;spawn()};reset();
  return dt=>{
    const press=key.a&&!pa;pa=key.a;
    if(over){hud(`Tower fell at ${n-1} blocks! Best ${best}. Press Space`);if(press)reset()}
    else{
      const s=(7+n*.3)*dt*dir;if(ax)m.position.z+=s;else m.position.x+=s;
      const q=ax?m.position.z:m.position.x;if(q>9)dir=-1;if(q<-9)dir=1;
      if(press){
        const dl=ax?m.position.z-top.z:m.position.x-top.x,len=ax?top.d:top.w;
        if(len-Math.abs(dl)<=0){over=true;best=hi('stack',n-1);m.material.color.set(0xff3355)}
        else{
          const d2=Math.abs(dl)<.2?0:dl,nl=len-Math.abs(d2);
          if(d2===0){perf++;cheer=1}else{perf=0;const cw=Math.abs(d2),cm=box(ax?top.w:cw,1,ax?cw:top.d,col(n)),o=Math.sign(dl)*len/2+dl/2;cm.position.set(ax?top.x:top.x+o,n+.5,ax?top.z+o:top.z);sc.add(cm);fa.push({m:cm,vy:0})}
          sc.remove(m);blocks.pop();
          const nx=ax?top.x:top.x+d2/2,nz=ax?top.z+d2/2:top.z;
          top={x:nx,z:nz,w:ax?top.w:nl,d:ax?nl:top.d};
          mk(nx,nz,top.w,top.d,n);n++;ax^=1;spawn()
        }
      }
      hud(`Height ${n-1}${perf>1?'   ·   ✨ Perfect x'+perf:''}   ·   Space / A drops`)
    }
    fa.forEach(f=>{f.vy-=30*dt;f.m.position.y+=f.vy*dt;f.m.rotation.x+=dt});for(let i=fa.length-1;i>=0;i--)if(fa[i].m.position.y<-30){sc.remove(fa[i].m);fa.splice(i,1)}
    bob.position.y=cheer>0?Math.abs(Math.sin(ET*9))*1.2:0;cheer=Math.max(0,cheer-dt);bob.userData.anim(cheer>0?1:0);orbit(cam,0,n+1,0);
  }
}
PH.games.push({id:'stack',title:'Tower Stack: Perfect Balance',genre:'Puzzle',emoji:'🗼',hero:'Builder Bob',desc:'Time each drop to stack a tall tower. Perfect drops keep the full width. Space or A.',run:stack,dist:15,pitch:.5});
