function meteor(sc,cam,hud){
  sc.background=new T.Color(0x080d20);sc.fog=new T.Fog(0x080d20,25,120);
  const floor=box(24,.4,120,0x192342);floor.position.set(0,-.3,-35);sc.add(floor);
  for(let x of [-5,0,5]){const l=box(.08,.04,120,0x4c5d91);l.position.set(x,.02,-35);sc.add(l)}
  const ship=avatar({shirt:0x72f1ff,pants:0x223366,hat:'helmet',s:.55});sc.add(ship);
  let x=0,z=0,objs=[],score=0,spawn=0,over=false;
  const reset=()=>{objs.forEach(o=>sc.remove(o.m));objs=[];x=0;z=0;score=0;spawn=.3;over=false};reset();
  return dt=>{
    if(over){hud(`Meteor field cleared you — score ${score|0}. Press Space to retry`);if(key.a)reset();return}
    const [mx,mz]=dirv();x=clamp(x+mx*13*dt,-10,10);z=clamp(z+mz*13*dt,-7,8);ship.position.set(x,0,z);if(mx||mz)ship.rotation.y=Math.atan2(mx,mz);
    spawn-=dt;if(spawn<=0){spawn=Math.max(.18,.7-score/900);const coin=Math.random()<.3,m=coin?new T.Mesh(new T.OctahedronGeometry(.55),mat(0xffdc50)):new T.Mesh(new T.IcosahedronGeometry(.8,0),mat(0xff466b));m.position.set((Math.random()-.5)*20,coin?1.2:.7,-70);sc.add(m);objs.push({m,coin,v:coin?24:22+Math.random()*12})}
    for(let i=objs.length-1;i>=0;i--){const o=objs[i];o.m.position.z+=o.v*dt;o.m.rotation.x+=dt*2;o.m.rotation.y+=dt*3;
      if(Math.hypot(o.m.position.x-x,o.m.position.z-z)<1.3){if(o.coin){score+=25;o.m.position.z=100}else{over=true}sc.remove(o.m);objs.splice(i,1);continue}
      if(o.m.position.z>10){if(o.coin)score+=5;sc.remove(o.m);objs.splice(i,1)}
    }
    orbit(cam,x*.4,2,z+6,0,1);hud(`Score ${score|0} · Collect gold crystals, dodge red meteors`);
  }
}
PH.games.push({id:'meteor',title:'Meteor Drift: Crystal Survival',genre:'Arcade',emoji:'☄️',hero:'Nova pilot',desc:'Dodge meteors and collect gold crystals in a fast endless survival run.',run:meteor,dist:13});
