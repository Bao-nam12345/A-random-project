function runner(sc,cam,hud){
  sc.background=new T.Color(0x140a30);sc.fog=new T.Fog(0x140a30,25,110);
  const road=box(10,.4,700,0x23235a);road.position.set(0,-.2,-300);sc.add(road);
  [-1.5,1.5].forEach(x=>{const l=box(.12,.05,700,0x00e5ff);l.position.set(x,.03,-300);sc.add(l)});
  const p=avatar({shirt:0x00bcd4,pants:0x1a237e,hat:'visor',s:.45});sc.add(p);const sb=new T.Mesh(new T.SphereGeometry(1.3,16,12),new T.MeshLambertMaterial({color:0x76ff03,transparent:true,opacity:.3}));sc.add(sb);
  const th=[];let lane,px,py,vy,sp,pts,tm,over,sh,best=0,pl=0,pr=0;
  const reset=()=>{th.forEach(o=>sc.remove(o.m));th.length=0;lane=0;px=0;py=0;vy=0;sp=20;pts=0;tm=0;sh=0;over=false};reset();
  return dt=>{
    if(over){hud(`Crashed! Score ${pts|0} · best ${best} - press Space`);if(key.a)reset();return}
    if(key.l&&!pl)lane=Math.max(-1,lane-1);if(key.r&&!pr)lane=Math.min(1,lane+1);pl=key.l;pr=key.r;
    px+=(lane*3-px)*Math.min(1,dt*12);
    if((key.a||key.u)&&py<=.001)vy=11;vy-=32*dt;py=Math.max(0,py+vy*dt);if(py===0&&vy<0)vy=0;
    p.position.set(px,py,0);p.rotation.y=Math.PI;p.userData.anim(py>0?.25:1);sb.visible=!!sh;sb.position.set(px,py+.8,0);
    sp+=dt*.4;pts+=dt*sp*.5;tm-=dt;
    if(tm<=0){tm=Math.max(.35,1.1-sp/60);const l=(Math.random()*3|0)-1,coin=Math.random()<.45,star=!coin&&Math.random()<.12;
      const m=coin?new T.Mesh(new T.TorusGeometry(.4,.14,8,16),mat(0xffd400)):star?new T.Mesh(new T.OctahedronGeometry(.55),mat(0x76ff03)):box(2,1.4,1,0xff3355);
      m.position.set(l*3,coin||star?1.1:.7,-90);sc.add(m);th.push({m,coin,star});
      const q=box(1,6+Math.random()*8,1,0x7a3cff);q.position.set((Math.random()<.5?-1:1)*(7+Math.random()*6),3,-90);sc.add(q);th.push({m:q,deco:1})}
    for(let i=th.length-1;i>=0;i--){const o=th[i];o.m.position.z+=sp*dt;if(o.coin||o.star)o.m.rotation.y+=dt*4;
      let kill=o.m.position.z>8;
      if(!o.deco&&Math.abs(o.m.position.z)<1&&Math.abs(o.m.position.x-px)<1.2){if(o.coin||o.star){if(o.star)sh=1;else pts+=25;kill=true}else if(py<.9){if(sh){sh=0;kill=true}else{over=true;best=hi('runner',pts|0)}}}
      if(kill){sc.remove(o.m);th.splice(i,1)}}
    orbit(cam,px*.6,1,-4,0,1);
    hud(`Score ${pts|0}${sh?'  🛡 shield':''}`)
  }
}
PH.games.push({id:'runner',title:'Neon Highway: Coin Rush',genre:'Arcade',emoji:'🚀',hero:'Neo, the visor runner',desc:'Sprint down a neon highway. Dodge barriers, grab coins and green shield stars. ◀ ▶ lanes, Space jumps.',run:runner,dist:11});
