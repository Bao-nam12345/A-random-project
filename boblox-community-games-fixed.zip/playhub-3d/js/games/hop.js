function hop(sc,cam,hud){
  sc.background=new T.Color(0x87ceeb);sc.fog=new T.Fog(0x87ceeb,50,180);
  const P=[],N=20,coins=[];
  const plat=(x,y,z,w,d,c,mvr)=>{const m=box(w,1,d,c);m.position.set(x,y-.5,z);sc.add(m);const p={m,x,y,z,w,d,mv:mvr||0,ox:x,ph:Math.random()*6,dx:0};P.push(p);return p};
  plat(0,0,0,8,8,0x4caf50);
  for(let i=1;i<=N;i++){const cp=i%5===0,p=plat(Math.sin(i*1.7)*3.5,i*1.1,-i*7.5,cp?6:4,cp?6:4,cp?0xffeb3b:new T.Color().setHSL(i/N,.7,.55).getHex(),(i%3===0&&!cp)?3:0);
    if(!cp&&!p.mv){const c=new T.Mesh(new T.TorusGeometry(.4,.14,8,16),mat(0xffd400));c.position.set(p.ox,p.y+1.5,p.z);sc.add(c);coins.push(c)}}
  const goal=plat(0,(N+1)*1.1,-(N+1)*7.5,7,7,0xffd400);
  const me=avatar({shirt:0xffffff,pants:0xf8bbd0,skin:0xffffff,hat:'ears',s:.5});sc.add(me);
  for(let i=0;i<14;i++){const c=ball(3+Math.random()*3,0xffffff);c.scale.y=.5;c.position.set((Math.random()-.5)*120,-6+Math.random()*30,-Math.random()*190);sc.add(c)}
  let x,y,z,vy,t,won,falls,cpt,got,stg,onp=null,face=0;
  const reset=()=>{x=0;y=0;z=0;vy=0;t=0;won=false;falls=0;cpt=[0,0,0];got=0;stg=0;onp=null;coins.forEach(c=>c.visible=true)};reset();
  return dt=>{
    if(won){hud(`You reached the top! ${t.toFixed(1)}s · 🪙 ${got} · falls ${falls} - press Space`);if(key.a)reset();return}
    t+=dt;
    P.forEach(p=>{const nx=p.ox+Math.sin(t*1.2+p.ph)*p.mv;p.dx=nx-p.x;p.x=nx;p.m.position.x=nx});
    if(onp)x+=onp.dx;
    const[mx,mz]=dirv();x+=mx*9*dt;z+=mz*9*dt;if(mx||mz)face=Math.atan2(mx,mz);
    vy-=30*dt;const py=y;y+=vy*dt;onp=null;
    for(const p of P)if(Math.abs(x-p.x)<p.w/2+.3&&Math.abs(z-p.z)<p.d/2+.3&&py>=p.y-.01&&y<=p.y&&vy<=0){y=p.y;vy=0;onp=p}
    if(onp&&key.a)vy=12.5;
    if(onp){const i=P.indexOf(onp);stg=Math.floor(i/5);if(i>0&&i%5===0)cpt=[onp.ox,onp.y,onp.z];if(onp===goal)won=true}
    coins.forEach(c=>{c.rotation.y+=dt*3;if(c.visible&&Math.hypot(c.position.x-x,c.position.z-z)<1.3&&Math.abs(c.position.y-y-1)<1.6){c.visible=false;got++}});
    if(y<-15){x=cpt[0];y=cpt[1]+.2;z=cpt[2];vy=0;falls++}
    me.position.set(x,y,z);me.rotation.y=face;me.userData.anim(onp?Math.hypot(mx,mz):.3);
    orbit(cam,x,y+1.5,z);
    hud(`Stage ${stg}/4 · ${t.toFixed(0)}s · 🪙 ${got} · falls ${falls}`)
  }
}
PH.games.push({id:'hop',title:'Rainbow Sky Obby: Checkpoint Climb',genre:'Platformer',emoji:'🌈',hero:'Hoppy the bunny',desc:'Climb a sky-high obstacle course with moving platforms, coins and checkpoints. Space jumps.',run:hop,dist:12});
